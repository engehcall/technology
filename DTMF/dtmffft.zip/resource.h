//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DTMFFFT.rc
//
#define IDR_MENU_DTMFFFT                102
#define IDD_DTMFFFT                     103
#define IDD_ABOUT                       104
#define IDD_PARAMETERS                  105
#define IDC_STATIC_PICTURE              1001
#define IDC_BUTTON_STARTSTOP            1003
#define IDC_COMBO_DEVICE                1004
#define IDC_EDIT_DTMF                   1006
#define IDC_EDIT_DTMF_DECODE            1007
#define IDC_EDIT_THRESHOLD              1008
#define IDC_SCROLLBAR_THRESHOLD         1011
#define IDC_EDIT_WINDOW                 1015
#define IDC_LIST_DECODE                 1017
#define IDC_PARAMETER_NAME1             1018
#define IDC_PARAMETER_OFFSET1           1019
#define IDC_DF_PARAMETER_NAME1          1019
#define IDC_PARAMETER_MULTIPLIER1       1020
#define IDC_DF_PARAMETER_VALUE1         1020
#define IDC_PARAMETER_UNITS1            1021
#define IDC_DF_PARAMETER_UNITS1         1021
#define IDC_PARAMETER_NAME2             1022
#define IDC_DF_PARAMETER_NAME2          1022
#define IDC_PARAMETER_OFFSET2           1023
#define IDC_DF_PARAMETER_UNITS2         1023
#define IDC_PARAMETER_MULTIPLIER2       1024
#define IDC_DF_PARAMETER_VALUE2         1024
#define IDC_PARAMETER_UNITS2            1025
#define IDC_DF_PARAMETER_NAME3          1025
#define IDC_PARAMETER_NAME3             1026
#define IDC_DF_PARAMETER_UNITS3         1026
#define IDC_PARAMETER_OFFSET3           1027
#define IDC_DF_PARAMETER_VALUE3         1027
#define IDC_PARAMETER_MULTIPLIER3       1028
#define IDC_DF_PARAMETER_NAME4          1028
#define IDC_PARAMETER_UNITS3            1029
#define IDC_DF_PARAMETER_UNITS4         1029
#define IDC_PARAMETER_NAME4             1030
#define IDC_DF_PARAMETER_VALUE4         1030
#define IDC_PARAMETER_OFFSET4           1031
#define IDC_PARAMETER_MULTIPLIER4       1032
#define IDC_PARAMETER_UNITS4            1033
#define IDC_PARAMETER_NAME5             1034
#define IDC_DF_PARAMETER_NAME5          1034
#define IDC_PARAMETER_OFFSET5           1035
#define IDC_DF_PARAMETER_UNITS5         1035
#define IDC_PARAMETER_MULTIPLIER5       1036
#define IDC_DF_PARAMETER_VALUE5         1036
#define IDC_PARAMETER_UNITS5            1037
#define IDC_DF_GRAPH                    1037
#define IDC_NUM_PARAMETERS              1038
#define IDM_ABOUT                       40001
#define IDM_EXIT                        40003
#define IDM_PARAMETERS                  40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
