// PARAMETER.C (c) 2004 Howard Long (G6LVB), Hanlincrest Ltd. All rights reserved.
// 72 Princes Gate
// London SW7 2PA
// United Kingdom
// howard@hanlincrest.com
// Free for educational and non-profit use. For commercial use please contact the author.

#define PARM_MAXPARAMETERS 5

#include <windows.h>
#include <stdio.h>

#include "resource.h"

#include "registry.h"
#include "parameter.h"

static BOOL ParameterSetString(HWND hdlg,char *pszKey,int nDlgID)
{
	char sz[30];

	GetDlgItemText(hdlg,nDlgID,sz,sizeof(sz));
	return RegSetString(pszKey,sz);
}

static BOOL ParameterGetString(HWND hdlg,char *pszKey,int nDlgID)
{
	char sz[30];

	if (!RegGetString(pszKey,sz,sizeof(sz)))
	{
		SetDlgItemText(hdlg,nDlgID,"");
		return FALSE;
	}

	SetDlgItemText(hdlg,nDlgID,sz);
	return TRUE;
}

static LRESULT CALLBACK ParameterDlg(HWND hdlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch (message) 
	{
		case WM_INITDIALOG:
			ParameterGetString(hdlg,"NumParameters",IDC_NUM_PARAMETERS);

			ParameterGetString(hdlg,"ParameterName1",IDC_PARAMETER_NAME1);
			ParameterGetString(hdlg,"ParameterOffset1",IDC_PARAMETER_OFFSET1);
			ParameterGetString(hdlg,"ParameterMultiplier1",IDC_PARAMETER_MULTIPLIER1);
			ParameterGetString(hdlg,"ParameterUnits1",IDC_PARAMETER_UNITS1);

			ParameterGetString(hdlg,"ParameterName2",IDC_PARAMETER_NAME2);
			ParameterGetString(hdlg,"ParameterOffset2",IDC_PARAMETER_OFFSET2);
			ParameterGetString(hdlg,"ParameterMultiplier2",IDC_PARAMETER_MULTIPLIER2);
			ParameterGetString(hdlg,"ParameterUnits2",IDC_PARAMETER_UNITS2);

			ParameterGetString(hdlg,"ParameterName3",IDC_PARAMETER_NAME3);
			ParameterGetString(hdlg,"ParameterOffset3",IDC_PARAMETER_OFFSET3);
			ParameterGetString(hdlg,"ParameterMultiplier3",IDC_PARAMETER_MULTIPLIER3);
			ParameterGetString(hdlg,"ParameterUnits3",IDC_PARAMETER_UNITS3);

			ParameterGetString(hdlg,"ParameterName4",IDC_PARAMETER_NAME4);
			ParameterGetString(hdlg,"ParameterOffset4",IDC_PARAMETER_OFFSET4);
			ParameterGetString(hdlg,"ParameterMultiplier4",IDC_PARAMETER_MULTIPLIER4);
			ParameterGetString(hdlg,"ParameterUnits4",IDC_PARAMETER_UNITS4);

			ParameterGetString(hdlg,"ParameterName5",IDC_PARAMETER_NAME5);
			ParameterGetString(hdlg,"ParameterOffset5",IDC_PARAMETER_OFFSET5);
			ParameterGetString(hdlg,"ParameterMultiplier5",IDC_PARAMETER_MULTIPLIER5);
			ParameterGetString(hdlg,"ParameterUnits5",IDC_PARAMETER_UNITS5);
			break;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					{
						char szNumParms[30];
						int n;

						GetDlgItemText(hdlg,IDC_NUM_PARAMETERS,szNumParms,sizeof(szNumParms));
						n=atoi(szNumParms);
						if (n<=0 || n>PARM_MAXPARAMETERS)
						{
							char szMessage[100];

							sprintf(szMessage,"Number of parameters must be between 1 and %d.",PARM_MAXPARAMETERS);
							MessageBox(hdlg,szMessage,"DTMFFFT",MB_ICONEXCLAMATION | MB_OK);
							return FALSE;
						}
					}
					ParameterSetString(hdlg,"NumParameters",IDC_NUM_PARAMETERS);

					ParameterSetString(hdlg,"ParameterName1",IDC_PARAMETER_NAME1);
					ParameterSetString(hdlg,"ParameterOffset1",IDC_PARAMETER_OFFSET1);
					ParameterSetString(hdlg,"ParameterMultiplier1",IDC_PARAMETER_MULTIPLIER1);
					ParameterSetString(hdlg,"ParameterUnits1",IDC_PARAMETER_UNITS1);

					ParameterSetString(hdlg,"ParameterName2",IDC_PARAMETER_NAME2);
					ParameterSetString(hdlg,"ParameterOffset2",IDC_PARAMETER_OFFSET2);
					ParameterSetString(hdlg,"ParameterMultiplier2",IDC_PARAMETER_MULTIPLIER2);
					ParameterSetString(hdlg,"ParameterUnits2",IDC_PARAMETER_UNITS2);

					ParameterSetString(hdlg,"ParameterName3",IDC_PARAMETER_NAME3);
					ParameterSetString(hdlg,"ParameterOffset3",IDC_PARAMETER_OFFSET3);
					ParameterSetString(hdlg,"ParameterMultiplier3",IDC_PARAMETER_MULTIPLIER3);
					ParameterSetString(hdlg,"ParameterUnits3",IDC_PARAMETER_UNITS3);

					ParameterSetString(hdlg,"ParameterName4",IDC_PARAMETER_NAME4);
					ParameterSetString(hdlg,"ParameterOffset4",IDC_PARAMETER_OFFSET4);
					ParameterSetString(hdlg,"ParameterMultiplier4",IDC_PARAMETER_MULTIPLIER4);
					ParameterSetString(hdlg,"ParameterUnits4",IDC_PARAMETER_UNITS4);

					ParameterSetString(hdlg,"ParameterName5",IDC_PARAMETER_NAME5);
					ParameterSetString(hdlg,"ParameterOffset5",IDC_PARAMETER_OFFSET5);
					ParameterSetString(hdlg,"ParameterMultiplier5",IDC_PARAMETER_MULTIPLIER5);
					ParameterSetString(hdlg,"ParameterUnits5",IDC_PARAMETER_UNITS5);

					EndDialog(hdlg,TRUE);
					break;
				case IDCANCEL:
					EndDialog(hdlg,FALSE);
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
	return FALSE;
}

BOOL Parameter(HWND hdlg, HINSTANCE hinst)
{
	return (BOOL)DialogBox(hinst,MAKEINTRESOURCE(IDD_PARAMETERS),hdlg,ParameterDlg);
}
