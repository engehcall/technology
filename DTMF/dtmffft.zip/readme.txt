DTMFFFT

Howard Long G6LVB

How it works

At 11025sps, it takes a ~43ms sample interval and analyses it into 128 frequency 'bins' (in conjunction with some other peripheral stuff, this is the function of the FFT - it converts an input in the time domain to an output in the frequency domain, like a spectrum analyser). At 11025 sps, the 128 bins are centered from ~21.5Hz to ~5534Hz at ~43Hz intervals. Each bin reflects the amount of energy in that bin's freqeuncy range.

To get an AGC level, it calcualtes an average of the bin contents in a passband for the frequencies of interest, from the bin just below the lowest DTMF tone to the bin just above the highest DTMF tone (about 1kHz from about 650Hz to 1680Hz), but when calulating the average it removes the bins matching the DTMF tones.

The product of the user-set level and the AGC level provides a threshold level (the horizontal line that jumps up and down). To trigger a DTMF frequency, the energy in each DTMF bin must exceed that threshold level.

To decode DTMF, there is a grid of buttons arranged in a 4x4 array:

      1209Hz 1336Hz 1477Hz 1633Hz
697Hz   1      2      3      A
770Hz   4      5      6      B
852Hz   7      8      9      C
941Hz   *      0      #      D

For a valid DTMF character to be produced, there must be a combination of (a) only one tone of (697, 770, 852 and 941Hz) and (b) only one tone of (1209, 1336, 1477 and 1633Hz). In addition, there must be two consecutive sample intervals of the same combination to trigger as a valid character.

There is some logic in there to not repeat a character once it has been recognised. However, this logic resets if (a) the same two-tone combination changes or disappears, (b) any additional DTMF tones are recognised. This second scenario is what causes false duplicates on particularly long tones (ie, tones lasting over five or more sample intervals) - the levels for the two-tone combination reset if another tone slips in over the current threshold. This could be rectified in a number of ways, for example by not resetting as long as the same two tones exist over the threshold level, ignoring other tones.

The DTMF nybbles are converted into hexadecimal using the following table:

Hex    DTMF
0      D
1      8
2      4
3      #
4      1
5      9
6      5
7      A
8      2
9      0
A      6
B      B
C      3
D      *
E      7
F      C

A string of n pairs (where n is defined in the Parameters dialog box, SSETI Express has n=3) of consecutive DTMF digits represents various parameters. The low nybble appears first. The n pairs of digits can only be considered as a valid value set if (a) they all occur within five seconds and (b) there was a previous gap in DTMF tones of at least five seconds prior to this.

Within the Parameters dialog box, the conversions from the decoded DTMF hex pairs (0x00 - 0xFF corresponding to 0 to 5V on the ADC inputs) allows a simple stright line multiplier and offset conversion to be applied. These conversions come from values calibrated during testing and integration. Note that if the offset or multiplier values are altered while the program is running, they take effect for the next incoming set of DTMF tones.

Initial calibration tests provided the following three sets of parameters for SSETI Express:

Parameter 1: Name=PA temp ; Offset=72.73292; Multipler=-0.31056; Units=deg C
Parameter 2: Name=PA power; Offset=-1.85455; Multipler=0.054545; Units=W
Parameter 3: Name=RSSI    ; Offset=-143.667; Multipler=0.392157; Units=dBm

The program also generates a .CSV file that can be imported directly into Excel. The format of this file includes the time in UTC format, the hexadecimal decoded telemetry, the five raw parameter values and the five converted calibrated parameter values.

Good luck!