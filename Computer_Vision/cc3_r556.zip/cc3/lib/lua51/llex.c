/*
** $Id: llex.c,v 2.20.1.1 2007/12/27 13:02:25 roberto Exp $
** Lexical Analyzer
** See Copyright Notice in lua.h
*/


#define llex_c
#define LUA_CORE

#include "lua.h"

#include "llex.h"


void luaX_init (lua_State *L) {
  UNUSED(L);
}
