This is based on Lua 5.1.2.

Please see the copyright notice in lua.h.

