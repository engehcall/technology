This is a port of the RDCF2 DOS FAT16 filesystem to the LPC2138.  While the
board I've used is a custom board, the Keil MCB2140 board is similar.  The
ony notable difference appears to be the MMC Chip Select and LED locations.

This software is under a BSD style of license.  It is free to use for hobby
or commercial purposes.  All that is asked is that you honor the copyright
notices placed in various files and keep them there.

A current source of the RDCF2 can be found on http://openhardware.net
This project was built under: binutils-2.15, gcc-3.4.3, insight-6.1,
and newlib-1.13.0 on a Mandriva Linux system.  Details on building your
own development environment can be found on http://openhardware.net .

I ask that any changes and improvements be sent to me so that others may 
benefit from your work, as well as mine.  Let's keep this free software
so that we don't have to go through this again with trying to find
something to read / write Flash FAT filesystems?  Thank you!

Tom Walsh - Nov 17, 2005 - http://openhardware.net


