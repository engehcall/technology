This directory is a placeholder for "virtual hardware" which
will execute on the host computer. This virtual-cam will
allow coding and debugging of vision algorithms without the
need for the external hardware board.

Functionality like this is often found in a "simulator" in
other products.
