Welcome to the "hal" directory.

A "hal", or hardware abstraction layer, is used to abstract high level
functionality away from a particular hardware implementation.

Currently there is only one hal in the cc3 project: the hardware 
implementation for the CMUcam3 board (based on the Philips LPC2106).

We plan to someday have some support for a simulator, which will be 
implemented partially in the virtual-cam directory.

More hardware support may follow!
