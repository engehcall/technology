This directory stores files common to all hardware layers.
