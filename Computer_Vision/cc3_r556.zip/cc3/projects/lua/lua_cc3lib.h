#ifndef LUA_CC3LIB_H
#define LUA_CC3LIB_H

#include "lua.h"

int open_cc3lib (lua_State *L);


#endif
