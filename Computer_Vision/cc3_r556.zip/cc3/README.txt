Welcome to cc3!
